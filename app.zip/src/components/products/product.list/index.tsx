import { AxiosResponse } from 'axios';
import { useEffect, useState } from 'react';
import { ApiResponse } from '../../../models/apiresponse';
import { Product } from '../../../models/product';
import { fetchProducts } from '../../../services/productservice';
import { ListComponent } from '../../common/list.component';

export const ProductList = () => {
  const [products, setProducts] = useState<Product[] | undefined>(undefined);
  const [error, setError] = useState<Error | undefined>(undefined);
  const [loading, setLoading] = useState<boolean>(false);
  useEffect(() => {
    const fetchProductsForComponent = () => {
      const p: Promise<AxiosResponse<ApiResponse<Product[]>>> = fetchProducts();
      p.then(
        (resp: AxiosResponse<ApiResponse<Product[]>>) => {
          const apiResponse = resp.data;
          if (apiResponse.data !== null) {
            setProducts(apiResponse.data);
          } else {
            setProducts(undefined);
          }
        },
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        (err: Error) => {
          setProducts(undefined);
          setError(err);
        },
      ).finally(() => {
        setLoading(false);
      });
    };

    setLoading(true);
    fetchProductsForComponent();
  }, []);

  if (error) {
    return <div>{error.message}</div>;
  }

  if (loading) {
    return <div>Loading...</div>;
  }

  const cellStyle: React.CSSProperties = {
    textAlign: 'center',
    border: 'black',
    borderStyle: 'ridge',
  };

  return (
    <div>
      <ListComponent
        style={{
          width: '100%',
          textAlign: 'center',
          border: 'black',
          borderStyle: 'groove',
        }}
        data={products ?? []}
        cols={[
          {
            key: 'imageUrl',
            label: 'Image URL',
            style: cellStyle,
            headerStyle: cellStyle,
            render(data) {
              return (
                <img
                  height={50}
                  width={50}
                  src={data.imageUrl}
                  alt={`logo-prod-${data.productId}`}
                ></img>
              );
            },
          },
          {
            key: 'productName',
            label: 'Name',
            style: cellStyle,
            headerStyle: cellStyle,
          },
          {
            key: 'productCode',
            label: 'Product Code',
            style: cellStyle,
            headerStyle: cellStyle,
          },
          {
            key: 'releaseDate',
            label: 'Release Date',
            style: cellStyle,
            headerStyle: cellStyle,
          },
          {
            key: 'description',
            label: 'Description',
            style: cellStyle,
            headerStyle: cellStyle,
          },
          {
            key: 'price',
            label: 'Price',
            style: cellStyle,
            headerStyle: cellStyle,
          },
          {
            key: 'starRating',
            label: 'Rating',
            style: cellStyle,
            headerStyle: cellStyle,
          },
        ]}
        rowUniqueIdentifierColName="productId"
      />
    </div>
  );
};
