import { ProductList } from '../products/product.list';

function App() {
  return <ProductList />;
}

export default App;
