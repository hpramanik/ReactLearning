export const Dashboard = () => {
  return <div>Dashboard</div>;
};
