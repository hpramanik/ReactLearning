export const PageNotFound = () => {
  return <div>Requested Resource Not Found</div>;
};
